function varargout = brushless_dc_motor(varargin)
% BRUSHLESS_DC_MOTOR M-file for brushless_dc_motor.fig
%      BRUSHLESS_DC_MOTOR, by itself, creates a new BRUSHLESS_DC_MOTOR or raises the existing
%      singleton*.
%
%      H = BRUSHLESS_DC_MOTOR returns the handle to a new
%      BRUSHLESS_DC_MOTOR or the handle to
%      the existing singleton*.
%
%      BRUSHLESS_DC_MOTOR('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in BRUSHLESS_DC_MOTOR.M with the given input arguments.
%
%      BRUSHLESS_DC_MOTOR('Property','Value',...) creates a new BRUSHLESS_DC_MOTOR or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before brushless_dc_motor_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to brushless_dc_motor_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help brushless_dc_motor

% Last Modified by GUIDE v2.5 17-Apr-2013 15:03:23

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @brushless_dc_motor_OpeningFcn, ...
                   'gui_OutputFcn',  @brushless_dc_motor_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before brushless_dc_motor is made visible.
function brushless_dc_motor_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to brushless_dc_motor (see VARARGIN)

% Choose default command line output for brushless_dc_motor
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes brushless_dc_motor wait for user response (see UIRESUME)
% uiwait(handles.figure1);
%im=imread('dc_motor.jpg');
axes(handles.axes1);
motor=imread('dc_motor.jpg');
image(motor);
axis off;

% --- Outputs from this function are returned to the command line.
function varargout = brushless_dc_motor_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in loop.
function loop_Callback(hObject, eventdata, handles)
% hObject    handle to loop (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if(evalin('base','loop_c') == 1)
    Kp = evalin('base','prop_gain');
    Ki = evalin('base','Intg_gain');
    Kd = evalin('base','Diff_gain');
    %% PID Equation
    numc = [Kd Kp Ki];
    denc = [1 0];
    %% convule "num with numc" and "den with denc"
    numa = conv(evalin('base','num'), numc);
    dena = conv(evalin('base','den'), denc);
    [numac, denac] = cloop(numa, dena);
    G = tf(numac, denac);
    assignin('base','tran_fn',G);
elseif(evalin('base','loop_o') == 1)
    G = tf(evalin('base','num'), evalin('base','den'));
    assignin('base','tran_fn',G);
else
    h = msgbox('Select the choice - open or closed loop');
end

%figure;
%rlocus(evalin('base','tran_fn'));
%if(evalin('base','loop_c') == 1)
%    title('Closed Loop Root Locus Diagram');
%else
%    title('Open Loop Root Locus Diagram');
%end
%title('Open Loop Root Locus Diagram');
%grid on;

    


function resist_Callback(hObject, eventdata, handles)
% hObject    handle to resist (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of resist as text
%        str2double(get(hObject,'String')) returns contents of resist as a double


% --- Executes during object creation, after setting all properties.
function resist_CreateFcn(hObject, eventdata, handles)
% hObject    handle to resist (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function induct_Callback(hObject, eventdata, handles)
% hObject    handle to induct (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of induct as text
%        str2double(get(hObject,'String')) returns contents of induct as a double


% --- Executes during object creation, after setting all properties.
function induct_CreateFcn(hObject, eventdata, handles)
% hObject    handle to induct (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function trq_cnst_Callback(hObject, eventdata, handles)
% hObject    handle to trq_cnst (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of trq_cnst as text
%        str2double(get(hObject,'String')) returns contents of trq_cnst as a double


% --- Executes during object creation, after setting all properties.
function trq_cnst_CreateFcn(hObject, eventdata, handles)
% hObject    handle to trq_cnst (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function mech_time_cnst_Callback(hObject, eventdata, handles)
% hObject    handle to mech_time_cnst (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of mech_time_cnst as text
%        str2double(get(hObject,'String')) returns contents of mech_time_cnst as a double


% --- Executes during object creation, after setting all properties.
function mech_time_cnst_CreateFcn(hObject, eventdata, handles)
% hObject    handle to mech_time_cnst (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function rotor_inertia_Callback(hObject, eventdata, handles)
% hObject    handle to rotor_inertia (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of rotor_inertia as text
%        str2double(get(hObject,'String')) returns contents of rotor_inertia as a double


% --- Executes during object creation, after setting all properties.
function rotor_inertia_CreateFcn(hObject, eventdata, handles)
% hObject    handle to rotor_inertia (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function phase_Callback(hObject, eventdata, handles)
% hObject    handle to phase (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of phase as text
%        str2double(get(hObject,'String')) returns contents of phase as a double


% --- Executes during object creation, after setting all properties.
function phase_CreateFcn(hObject, eventdata, handles)
% hObject    handle to phase (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in evaluate.
function evaluate_Callback(hObject, eventdata, handles)
% hObject    handle to evaluate (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
R = str2num(get(handles.resist, 'String'));
L = str2num(get(handles.induct, 'String'));
Kt = str2num(get(handles.trq_cnst, 'String'));
tm = str2num(get(handles.mech_time_cnst, 'String'));
J = str2num(get(handles.rotor_inertia, 'String'));
p = str2num(get(handles.phase, 'String'));
clsdloop = 0;
assignin('base','loop_c',clsdloop);
opnloop = 1;
assignin('base','loop_o',opnloop);
%% Calculations
te = L/(p*R);                        %seconds, s, Electrical time constant Terminal Resistance phase to phase
Ke = 3*R*J/(tm*Kt);                  %Back emf constant
o_num = [1/Ke];
o_den = [tm*te tm 1];
assignin('base','num',o_num);
assignin('base','den',o_den);

% --- Executes on button press in oloop.
function oloop_Callback(hObject, eventdata, handles)
% hObject    handle to oloop (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
opnloop = 1;
clsdloop = 0;
assignin('base','loop_c',clsdloop);
assignin('base','loop_o',opnloop);

% Hint: get(hObject,'Value') returns toggle state of oloop


% --- Executes on button press in cloop.
function cloop_Callback(hObject, eventdata, handles)
% hObject    handle to cloop (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of cloop
prompt = {'Enter P Gain:','Enter I Gain:','Enter D Gain:'};
dlg_title = 'PID Gains:';
num_lines = 1;
def = {'0.5','0.0','0.0'};
answer = inputdlg(prompt,dlg_title,num_lines,def);
if (isempty(answer))
    return;
end
P_gain = str2num(answer{1});
I_gain = str2num(answer{2});
D_gain = str2num(answer{3});
clsdloop = 1;
assignin('base','loop_c',clsdloop);
assignin('base','prop_gain',P_gain);
assignin('base','Intg_gain',I_gain);
assignin('base','Diff_gain',D_gain);

% --- Executes on button press in stp_resp.
function stp_resp_Callback(hObject, eventdata, handles)
% hObject    handle to stp_resp (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%% Plot the step response
%if(evalin('base','loop_c') == 1)
%elseif(evalin('base','loop_o') == 1)


% Hint: get(hObject,'Value') returns toggle state of stp_resp


% --- Executes on button press in r_locus.
function r_locus_Callback(hObject, eventdata, handles)
% hObject    handle to r_locus (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of r_locus


% --- Executes on button press in nyqu.
function nyqu_Callback(hObject, eventdata, handles)
% hObject    handle to nyqu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hint: get(hObject,'Value') returns toggle state of nyqu


% --- Executes on button press in bode_gen.
function bode_gen_Callback(hObject, eventdata, handles)
% hObject    handle to bode_gen (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of bode_gen


% --- Executes on button press in bode_wd_freq.
function bode_wd_freq_Callback(hObject, eventdata, handles)
% hObject    handle to bode_wd_freq (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of bode_wd_freq


% --- Executes on button press in bode_disc_resp.
function bode_disc_resp_Callback(hObject, eventdata, handles)
% hObject    handle to bode_disc_resp (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of bode_disc_resp


% --- Executes on button press in view_graph.
function view_graph_Callback(hObject, eventdata, handles)
% hObject    handle to view_graph (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

show_r_loc = get(handles.r_locus, 'Value');
show_step_res = get(handles.stp_resp, 'Value');
show_nyq = get(handles.nyqu, 'Value');
show_bode_sim = get(handles.bode_gen, 'Value');
show_bode_wd = get(handles.bode_wd_freq, 'Value');
show_bode_disc = get(handles.bode_disc_resp, 'Value');
%%%%%%%%% Pressure Variation %%%%%%%%%%%%%%%%

if(show_step_res == 1)
    figure
    step(evalin('base','tran_fn'),0.5);
    if(evalin('base','loop_c') == 1)
        title('Closed Loop Step Response Diagram');
    else
        title('Open Loop Step Response Diagram');
    end
    %title('Open Loop Step Response Diagram');
    xlabel('Time, secs');
    ylabel('Voltage, volts');
    grid on;
end
if(show_r_loc == 1)
    %% Plot the Root-locus
    figure;
    rlocus(evalin('base','tran_fn'));
    if(evalin('base','loop_c') == 1)
        title('Closed Loop Root Locus Diagram');
    else
        title('Open Loop Root Locus Diagram');
    end
    %title('Open Loop Root Locus Diagram');
    grid on;
end
if(show_nyq == 1)
    %% Plot the Nyquist diagram
    figure;
    nyquist(evalin('base','tran_fn'));
    if(evalin('base','loop_c') == 1)
        title('Closed Loop Nyquist Diagram');
    else
        title('Open Loop Nyquist Diagram');
    end
    %title('Open Loop Nyquist Diagram');
    grid on;
end
if(show_bode_sim == 1)
    %% Plot the Bode Plot
    figure;
    bode(evalin('base','tran_fn'));
    if(evalin('base','loop_c') == 1)
        title('Closed Loop Bode Plot Diagram 1');
    else
        title('Open Loop Bode Plot Diagram 1');
    end
    %title('Open Loop Bode Plot Diagram 1');
    grid on;
end
if(show_bode_wd == 1)
    %% Plot the Bode Plot
    figure;
    bode(evalin('base','tran_fn'), {0.1, 100});
    if(evalin('base','loop_c') == 1)
        title('Closed Loop Bode Plot Diagram with wider frequency spacing');
    else
        title('Open Loop Bode Plot Diagram with wider frequency spacing');
    end
    %title('Open Loop Bode Plot Diagram with wider frequency spacing');
    grid on;
end
if(show_bode_disc == 1)
    figure;
    GD = c2d(evalin('base','tran_fn'), 0.5);
    bode(evalin('base','tran_fn'), 'r', GD, 'b--');
    if(evalin('base','loop_c') == 1)
        title('Closed Loop Bode Plot Diagram with discretised response');
    else
        title('Open Loop Bode Plot Diagram with discretised response');
    end
    %title('Open Loop Bode Plot Diagram with discretised response');
    grid on;
end

