Using Statistics for Uncertainty Analysis in System Models - Webinar - 30 November 2006

The files contained in this zip file are from the 30 November 2006 webinar.
It is recommended you view the webinar prior to running these files.  To
view the webinar, go to http://www.mathworks.com/webinars and look for the
'Using Statistics for Uncertainty Analysis in System Models' webinar.

A copy of the presentation slides from the Webinar are included in this download.

Please be aware that you will need MATLAB(R) and Statistics Toolbox to run 
the code in this download. Some files require Simulink, Aerospace Toolbox,
SimPowerSystems, SimDriveline, and Aerospace Blockset to be installed to view
and run the Simulink based models but are not required to run the MATLAB files.

To request a trial of these products please visit:

http://www.mathworks.com/products/statistics/tryit.html

You should step through DCMotorDemo_walktrhough.m in cell execution mode so
that you can see the results in a sequence shown in the webinar on November 27.  To enable
cell mode, first open the M-file by typing "edit DCMotorDemo" at the MATLAB 
command prompt.  Once the editor opens, go to the "Cell" menu and select
"Enable Cell Mode".  Once cell mode is enabled, you can right-click within 
each cell (cells begin with %%) and select "Evaluate Current Cell".

This script is commented such that it produces a detailed report if you 
publish it (original in downloaded HTML folder).  This report includes 
background information, a description of what the code is doing, Code 
samples, figures, and an analysis of the results.  To publish the M-file, 
go to the "File" menu within the editor and "Publish To" your desired file 
format.

---------------------------------------------------------------------------
Contained in this download are:

General:       
   README.txt                            this document
   Using Statistics for Uncertainty Analysis in System Models.pdf     
                                        presentation slides

Webinar Archive Direct Link:
    http://www.mathworks.com/wbnr13340

M-Files:
   DCMotorDemo_walktrhough.m            Walkthrough of the demo (read 1st)                        
   coded2real.m                         Converts DOE to real units
   mcColorMap.m                         Color map creation function 
   myDCMotorFit.m                       Function to extract rise time/velocity
   myDistFit.m                          Fit temperature distribution
   myProbFit.m                          Fit rise time to distribution
   plotByColorMap.m                     Color map plotting function
   plotMotorSim.m                       Plot showing simulation status
   runDCMotorMCSim.m                    Monte-Carlo simulation driver
   runDCMotorSim.m                      DOE simulation driver script
   showDOETable.m                       DOE table display
   verifyInstalled.m                    Check for needed products

MAT-Files:
DCMotorSim.mat                          Results of DOE simulation                 
DCMotorTest.mat                         Motor DOE test results
mcresults.mat                           Monte-Carlo simulation results
MotorSpecCheck.mat                      Reusults of simulation to specs
RTVdata.mat                             Rise time/voltage from DCMotorTest
SimRTVCalc.mat                          Rise time/voltage from DCMotorSim
Temperature.mat                         Historical temperature data

MDL-Files:
   MaxonDCMotor.mdl                     Simulink model of the motor
                                        Requires Simulink, SimPowerSystems,
                                        Aerospace Toolbox, Aerospace blockset,
                                        and SimDriveline.
       
HTML Folder:
   MATLAB published version of DCMotorDemo_walkthrough.m.  To view, open 
   DCMotorDemo_walkthrough.html in a web browser.

---------------------------------------------------------------------------
Questions/Comments:
stuart.kozola@mathworks.com