function overshoot_out=overshoot(index,limit,T,output,inputvalue)   %this function will calculate total percentage overshoot
for m=1:index                                                       % for steps referencemthe step signal may be single step or multiple steps
    tfind_start=limit(m,1);
    tfind_stop=limit(m,2);
     for n1=1:size(T)
      if T(n1)>= tfind_start
         tstart_dimension=n1;
         break;
      end
     end
   for n2=1:size(T)
       if T(n2) >= tfind_stop
             tstop_dimension=n2;
             break;
        end
   end
   overshoot_max(m,:)=output(tstart_dimension,1);
   if m==1
           input_value=0;
   else
           input_value=inputvalue(1,(m-1));
   end
   for i=tstart_dimension : (tstop_dimension-1)
       if input_value>inputvalue(1,m)
           if ((overshoot_max(m,1)>output(i+1,1))&&(output(i+1,1)<input_value))
              overshoot_max(m,1)=output(i+1,1);
           end
       else
           if ((overshoot_max(m,1)<output(i+1,1))&&(output(i+1,1)>input_value))
              overshoot_max(m,1)=output(i+1,1);
           end
       end
   end
   if input_value > inputvalue(1,m)
     
       overshoot_max(m,1)=(((inputvalue(1,m)-overshoot_max(m,1))/abs(inputvalue(1,m)-input_value))*100);
   else
   
       overshoot_max(m,1)=(((overshoot_max(m,1)-(inputvalue(1,m)-input_value))/(inputvalue(1,m)-input_value))*100);
   end
   if overshoot_max(m,1)< 0
       overshoot_max(m,1)=0;
   end
end
overshoot_out=0;
for i=1:m
    overshoot_out=(overshoot_out+overshoot_max(i,1));
end
 overshoot_out= overshoot_out/index;
end
       
       
       
    