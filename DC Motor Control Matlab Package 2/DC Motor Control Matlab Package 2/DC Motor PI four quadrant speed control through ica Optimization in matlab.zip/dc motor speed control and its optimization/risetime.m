function rs_time=risetime(index,limit,T,output,inputvalue)   % this function will calculate total percentage risetime
for m=1:index                                                % for steps referencemthe step signal may be single step or multiple steps
    tfind_start=limit(1,m);
    tfind_stop=limit(m,2);
     for n1=1:size(T)
      if T(n1)>= tfind_start
         tstart_dimension=n1;
         break;
      end
   end
   for n2=1:size(T)
       if T(n2) >= tfind_stop
             tstop_dimension=n2;
             break;
        end
   end
   if m==1
       step_level=inputvalue(1,m);
       initial=0;
   else
       if inputvalue(1,(m-1))>inputvalue(1,m)
           step_level=inputvalue(1,(m-1))-inputvalue(1,m);
           initial=inputvalue(1,(m-1));
       else
         step_level=inputvalue(1,m)-inputvalue(1,(m-1));
         initial=inputvalue(1,(m-1));
       end
   end
   ten_perecentage=step_level*.1;
   ninty_percentage=step_level*.9;
   if m==1
   for i=tstart_dimension : tstop_dimension
       if output(i,1)>=initial+ten_perecentage
           rs_t1=T(i);
           break;
       end
   end
   for i=tstart_dimension : tstop_dimension
       if output(i,1)>=initial+ninty_percentage
           rs_t2=T(i);
           break;
       end
   end 
   else
   if inputvalue(1,(m-1))>inputvalue(1,m)
   for i=tstart_dimension : tstop_dimension
       if output(i,1)<=initial-ten_perecentage
           rs_t1=T(i);
           break;
       end
   end
   for i=tstart_dimension : tstop_dimension
       if output(i,1)<=initial-ninty_percentage
           rs_t2=T(i);
           break;
       end
   end
   else
   for i=tstart_dimension : tstop_dimension
       if abs(output(i,1))>=abs(initial+ten_percentage)
           rs_t1=T(i);
           break;
       end
   end
   for i=tstart_dimension : tstop_dimension
       if abs(output(i,1))>=abs(initial+ninty_percentage)
           rs_t2=T(i);
           break;
       end
   end
   end
   end
   rs_t(m,:)=rs_t2-rs_t1;
end
rs_time=0;
for m=1:index
rs_time=rs_time+rs_t(m,1);
end
end