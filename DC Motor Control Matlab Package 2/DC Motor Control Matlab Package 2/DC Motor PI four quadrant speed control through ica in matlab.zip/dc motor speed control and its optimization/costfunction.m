%the cost function
%the cost function for optimization of PI controller of dc motor speed controller
%here total error, rise time, settling time, overshoot are used to determine the cost
%krishnendu mukherjee
%e-mail:-krishnendumailbox@gmail.com
%release date 11/06/2012
function z = mufunc(x,number)  
for i=1:size(x(:,1),1)         
    clear Kpv;
    clear Kiv;
    Kpv=x(i,1);
    Kiv=x(i,2);
    %Kpc=x(i,3);   as here speed controller is only to be optimized,
    %Kic=x(i,4);   the values of the current controller are not used
    putvar(Kpv,Kiv); 
    %putvar(Kpv,Kiv,Kpc,Kic);
    Kpv
    Kiv
    %Kpc
    %Kic
   [T X Y1 Y2] =sim('dc_motor_speed_controller',[0 1.26]); %processing the model of dc motor speed controller
    n=[.2 .74;.74 1.26]; %n is the matrix which represent the different step times of reference signal as like for constant signal4 in the signal builder in model you have to use n=[0 1.26] and input=[100]
    input=[100 -50]; %input matrix is the values of reference signal at different steps,please check the reference signal of the model to make it clear
    error=steadystateerror(2,n,T,Y1,input);   %here 2 represents no. of steps for constant signal you have to use 1
    t_st=settlingtime(2,n,T,Y1,input);
    Ymax=overshoot(2,n,T,Y2,input);
    t_rs=risetime(2,n,T,Y2,input);
    z(i,:)=(2*error+5*Ymax+6*t_st+2.5*t_rs);%here priority is given to 
                                           %different paramaters which are to be minimized,you can try by giving different priority to different parameters for better
end 
z
end