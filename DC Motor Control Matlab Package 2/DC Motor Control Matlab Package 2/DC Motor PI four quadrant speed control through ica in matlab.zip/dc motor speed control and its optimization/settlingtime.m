function ts = settlingtime1(index,limit,T,output,inputvalue)  % this function will calculate total percentage setling time 
for m=1:index                                                 % for steps referencemthe step signal may be single step or multiple steps 
  find=0;
  tfind_start=limit(m,1);
  tfind_stop=limit(m,2);
  if m==1
      input_value=inputvalue(1,m);
  else
  input_value=abs(inputvalue(1,m)-inputvalue(1,(m-1)));
  end
  for n1=1:size(T)
      if T(n1)>= tfind_start
         tstart_dimension=n1;
         break;
      end
   end
   for n2=1:size(T)
       if T(n2) >= tfind_stop
             tstop_dimension=n2;
             break;
        end
   end
   for i=tstart_dimension : tstop_dimension
      
       if find==1
          break; 
       end
       
           
          for j=i+1 : (tstop_dimension-1)
              
              if abs(output(j)-output(i))>(.009*input_value)
                 break;
              end
              if j==(tstop_dimension-1)
                 find=1;
                 ts_temp(m,1)=(((T(i)-T(tstart_dimension))/(tfind_stop-tfind_start))*100);
              end
          end
    end
   if find==0
             ts_temp(m,1)=.6
   end       
   end
ts=0;
for i=1:index
    ts=ts+ts_temp(i,1);
end
end
