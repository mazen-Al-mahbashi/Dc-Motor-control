function ess=steadystateerror(index,limit,T,output,inputvalue)   % this function will calculate total percentage error
for m=1:index                                                    % for steps referencemthe step signal may be single step or multiple steps 
y=0;
tfind_start=limit(m,1);
tfind_stop=limit(m,2);
if m==1
      input_value=inputvalue(1,m);
else
  input_value=abs(inputvalue(1,m)-inputvalue(1,(m-1)));
end
for n1=1:size(T)
      if T(n1)>= tfind_start
         tstart_dimension=n1;
         break;
      end
   end
   for n2=1:size(T)
       if T(n2) >= tfind_stop
             tstop_dimension=n2;
             break;
        end
   end
    for j=tstart_dimension:tstop_dimension-1
        y=(output(j)*(T(j+1)-T(j)))+y;
    end
    yintegrl(m,1)=y/(tfind_stop-tfind_start);
    y_percentage(m,1)=(yintegrl(m,1)/input_value)*100;
end
ess=0;
for i=1:index
    ess=(y_percentage(i,1)+ess);
end
ess=ess/index;
end